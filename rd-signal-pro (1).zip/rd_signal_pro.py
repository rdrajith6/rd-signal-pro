
import requests
import time
from datetime import datetime

BOT_TOKEN = "YOUR_BOT_TOKEN"
CHAT_ID = "YOUR_CHAT_ID"

CURRENCY_PAIRS = [("EUR", "USD"), ("GBP", "USD"), ("USD", "JPY"), ("AUD", "USD"), ("USD", "CAD")]
previous_rates = {}
cooldown = {}

def get_rate(pair):
    try:
        base, quote = pair
        url = f"https://api.currencyapi.com/v3/latest?apikey=fca_live_V5Dks0HRSQD9yb6ANQf0W2iDUsHiSbYJBXA20yP1&currencies={quote}&base_currency={base}"
        res = requests.get(url)
        data = res.json()
        return float(data['data'][quote]['value'])
    except Exception as e:
        print("Rate fetch failed:", e)
        return None

def send_signal(pair, signal, rate):
    base, quote = pair
    message = f"""✿ RD SIGNAL PRO ✿
----------------------
🕓 Time: {datetime.utcnow().strftime('%H:%M')}
💱 Pair: {base}{quote}
📈 Type: {signal}
----------------------
⚠️ Follow Money Management
Avoid Trade If Previous Candle Doji/Wick/Big Body!
Avoid Trade In Opposite Trend!"""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    requests.post(url, json={"chat_id": CHAT_ID, "text": message})

while True:
    for pair in CURRENCY_PAIRS:
        now = time.time()
        if cooldown.get(pair, 0) > now:
            continue

        rate = get_rate(pair)
        if rate is None:
            continue

        if pair not in previous_rates:
            previous_rates[pair] = rate
            continue

        diff = rate - previous_rates[pair]
        if abs(diff) > 0.00015:
            signal = "CALL" if diff > 0 else "PUT"
            send_signal(pair, signal, rate)
            previous_rates[pair] = rate
            cooldown[pair] = now + 1200  # 20 mins cooldown

    time.sleep(60)
